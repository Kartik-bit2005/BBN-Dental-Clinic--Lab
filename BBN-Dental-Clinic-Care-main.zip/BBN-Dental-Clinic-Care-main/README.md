<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Dental Lab | Book Appointment</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0; padding: 0;
      background-color: #f5f5f5;
      color: #333;
    }
    header {
      background-color: #0a74da;
      color: white;
      padding: 20px;
      text-align: center;
    }
    nav {
      background-color: #004c99;
      text-align: center;
      padding: 10px;
    }
    nav a {
      color: white;
      margin: 0 15px;
      text-decoration: none;
    }
    section {
      padding: 30px;
      background-color: white;
      margin: 20px;
      border-radius: 10px;
    }
    h2 {
      color: #0a74da;
    }
    form input, form select, form textarea {
      width: 100%;
      padding: 10px;
      margin: 10px 0;
      border-radius: 5px;
      border: 1px solid #ccc;
    }
    form button {
      background-color: #0a74da;
      color: white;
      padding: 12px 20px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
    form button:hover {
      background-color: #004c99;
    }
    footer {
      background-color: #222;
      color: white;
      text-align: center;
      padding: 15px;
    }
  </style>
</head>
<body>

  <header>
    <h1>BBN Dental Care Lab & Clinic</h1>
    <p>Premium Dental Prosthetics & Services</p>
  </header>

  <nav>
    <a href="#about">About</a>
    <a href="#services">Services</a>
    <a href="#appointment">Book Appointment</a>
    <a href="#contact">Contact</a>
  </nav>

  <section id="about">
    <h2>About Us</h2>
    <p>BBN Dental Care Lab & Clinic is dedicated to providing top-quality dental prosthetics and lab services to clinics and patients. With advanced technology and experienced technicians, we deliver excellence in every smile.</p>
  </section>

  <section id="services">
    <h2>Our Services</h2>
    <ul>
      <li>Crowns & Bridges</li>
      <li>Dentures (Full & Partial)</li>
      <li>Cap</li>
      <li>Custom Shade Matching</li>
      <li>Root Canal</li>
      <li>Fixed Partial Dentures</li>
      <li>Orthodontic Care</li>
      <li>teeth scaling</li>
      
    </ul>
  </section>

  <section id="appointment">
    <h2>Book an Appointment</h2>
    <form action="#" method="post">
      <label for="name">Full Name</label>
      <input type="text" id="name" name="name" placeholder="Your name" required>

      <label for="email">Email Address</label>
      <input type="email" id="email" name="email" placeholder="you@example.com" required>

      <label for="phone">Phone Number</label>
      <input type="tel" id="phone" name="phone" placeholder="123-456-7890" required>

      <label for="date">Preferred Date</label>
      <input type="date" id="date" name="date" required>

      <label for="service">Service Required</label>
      <select id="service" name="service">
        <option value=>Crowns & Bridges</option>
        <option value=>Dentures</option>
        <option value=>Fixed Partial Dentures</option>
        <option value=>Root Canal</option>
        <option value=>Orthodontic Care</option>
        <option value=>teeth scaling</option>
        <option value=>Cap</option>
        <option value=>Dentures (Full & Partial)</option>

      </select>

      <label for="message">Additional Notes</label>
      <textarea id="message" name="message" rows="4" placeholder="Any specific request or issue?"></textarea>

      <button type="submit">Submit Appointment</button>
    </form>
  </section>

  <section id="contact">
    <h2>Contact Us</h2>
    <p><strong>Address:</strong> #484 BBN Dental Care & Clinic Street, Punjab,Nayagaon,Govind nagar,Karoran road,distt-Mohali, India</p>
    <p><strong>Phone:</strong> +91-8882298398 & 9463634842</p>
    <p><strong>Email:</strong> bbndentalclinic@gmail.com</p>
    <p><strong>Working Hours:</strong> Sun–Sat: 10:00 AM – 2:00 PM</p>
  </section>

  <footer>
    <p>&copy; 2025 BBN Dental Care Lab & Clinic. All rights reserved.</p>
  </footer>

</body>
</html>
